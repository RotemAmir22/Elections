//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_DEMOCRATICLEADER_H
#define ASSIGNMENT5_DEMOCRATICLEADER_H
#include "Politician.h"
/*
 * this class is to help identify the politician
 * all the democratic leaders are of this class
 * publicly inherits from politician
 * has no additional members
 */
class DemocraticLeader :public  Politician{
public:
    //constructor
    DemocraticLeader(string firstName, string lastName, string ID, int power) :Politician(firstName,lastName,ID,power){}
    //destructor
    virtual ~DemocraticLeader(){}
    //print politician
    virtual bool displayPolitician()const;
    //gets politicians power at primaries
    virtual int getPrimariesPower()const{return _power;}
    //gets politicians power at elections
    virtual int getElectionsPower()const{return _power;}
    //check if politician can be a member of a party
    virtual bool canBeMember(Party *party){return party->handleDemocrat(this);};

};


#endif //ASSIGNMENT5_DEMOCRATICLEADER_H
