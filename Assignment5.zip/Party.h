//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_PARTY_H
#define ASSIGNMENT5_PARTY_H
#include <vector>
#include <iostream>
#include "Politician.h"
using namespace std;
/*
 * this class defines a party in general.
 * has protected members:
 *  - name
 *  - chairman
 *  - members
 *  - size
 *  
 *  class is a subject
 */

//uses politician
class Politician;

class Party {
protected:
    string _name;
    Politician *_chairman;
    vector<Politician*> _members;
    int _size;

public:
    //constructor
    Party(string name);
    //destructor
    virtual ~Party();
    //add member to party
    bool addMember(Politician *politician);
    //remove member from party
    bool removeMember(Politician *politician);
    //run primaries in party
    bool primaries();
    // party power
    int partyPower();
    //pure virtual: print -> is initialized by inherited classes
    virtual bool displayParty()=0;
    //get methods
    //party size
    int getSize() const{return _size;}
    //party chairman
    Politician *getChairman()const{return _chairman;}
    //party name
    string getName(){return _name;}
    //party members
    vector<Politician*> getMembers(){return  _members;}
    //this class is a subject, so notifies its observers
    bool notify();
    //if politician can be part of party, adds, if not, false
    virtual bool handleRepublican(Politician *politician)=0;
    virtual bool handleDemocrat(Politician *politician)=0;
};


#endif //ASSIGNMENT5_PARTY_H
