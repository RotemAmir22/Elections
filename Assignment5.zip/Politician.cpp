//
// Created by ise on 1/6/23.
//
#include <iostream>
#include "Politician.h"
/*
 * constructor
 * gets full name, id and power. initializes chairman and party to nullptr
 */
Politician::Politician(string firstName, string lastName, string ID, int power) {
    _firstName = firstName;
    _lastName=lastName;
    _ID=ID;
    _party= nullptr;
    _chairman= nullptr;
    _power=power;
}
/*
 * this class is an observer therefore has to be updated by its subject
 * in this case, the subject is the party
 * returns true - successful even if pointer is nullptr
 */
bool Politician::update() {
    //updates chairman
    _chairman = _party->getChairman();
    return true;
}



