//
// Created by ise on 1/6/23.
//

#ifndef ASSIGNMENT5_POLITICIAN_H
#define ASSIGNMENT5_POLITICIAN_H
#include <iostream>
#include "Party.h"
using namespace std;
/*
 * this class defines a politician in general.
 * has protected members:
 *  - firstname
 *  - lastname
 *  - ID
 *  - party that this politician a member of
 *  - chairman of the party that the politician is a part of
 *  - power
 *
 *  class is an observer
 */

//uses party
class Party;

class Politician {
protected:
    string _firstName;
    string _lastName;
    string _ID;
    Party *_party;
    Politician *_chairman;
    int _power;

public:
    //constructor
    Politician(string firstName, string lastName, string ID, int power);
    //destructor
    virtual ~Politician(){}
    //pure virtual: print -> is initialized by inherited classes
    virtual bool displayPolitician()const=0;
    // class is an observer, gets updated from party (subject)
    bool update();
    //get methods
    //politician id
    string getID()const{return _ID;}
    //politician name
    string getName()const{return _firstName;}
    //politician party
    Party *getParty(){return _party;}
    //set method
    //set politician party
    bool setParty(Party* party){_party=party;return true;}
    //pure virtual: primaries power -> is initialized by inherited classes
    virtual int getPrimariesPower()const=0;
    //pure virtual: election power -> is initialized by inherited classes
    virtual int getElectionsPower()const=0;
    //check if politician can be a member of a party
    virtual bool canBeMember(Party *party)=0;

};


#endif //ASSIGNMENT5_POLITICIAN_H
