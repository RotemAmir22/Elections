//
// Created by ise on 1/7/23.
//

#include "Party.h"
/*
 * constructor
 * gets name, initializes chairman to nullptr and size to 0
 */
Party::Party(string name) {
    _name=name;
    _chairman = nullptr;
    _size=0;
}

//destructor, clears the vector
Party::~Party() {
        _members.clear();
}
/*
 * add member to party
 * gets a pointer to new politician
 * returns bool, true if successful and false if not
 */
bool Party::addMember(Politician *politician) {
    //check pointers
    if(politician == nullptr)
        return false;
    //add politician to end of vector
    _members.push_back(politician);
    //set this party to the politician (new member of this party)
    politician->setParty(this);
    //check chairman has been chosen and update the new party member
    if(_chairman!= nullptr)
        politician->update();
    //update size
    _size++;
    return true;
}
/*
 * removes party member from party
 * gets a pointer to party member to remove
 * returns bool, true if successful and false if not
 */
bool Party::removeMember(Politician *politician) {
    //check pointer
    if(politician == nullptr)
        return false;

    //go over members of party
    vector<Politician*>::iterator it;
    for (it = _members.begin();it!=_members.end(); ++it)
    {
        //if member found
        if(politician->getID() == (*it)->getID())
        {
            //remove from vector
            _members.erase(it);
            break;
        }
    }
    //if the member eas the chairman
    if(politician == _chairman)
    {
        //chairman has been removed
        _chairman = nullptr;
        //notify all the party members
        notify();
        politician->update();
    }
    //update size
    _size--;
    return true;
}

/*
 * runs primaries on party.
 * calculates which politician leader has the maximum power.
 * the politician with maximum power is chosen
 * if no one is chosen, the functions is still successful, and inplace of the chairman is still nullptr/none.
 */
bool Party::primaries() {
    //if there are no members
    if(_size == 0)
    {
        //print that none is the chairman
        cout << "None is the chairman of " << _name << endl;
        return true;
    }
    //go over members of party
    vector<Politician*>::iterator it;
    //set the first politician to the temporary chairman (if nullptr, then no change has occurred)
    _chairman = _members.front();
    for (it = _members.begin();it != _members.end(); ++it)
    {
        //compare powers and update if member has more power
        if((*it)->getPrimariesPower() > _chairman->getPrimariesPower())
            _chairman = *it;
    }
    //check if the chairman is a leader
    if(_chairman->getPrimariesPower() == -1)
    {
        //if not, then no chairman has been chosen
        _chairman = nullptr;
        //print that none is the chairman
        cout << "None is the chairman of " << _name << endl;
    }
    else //chairman has been chosen
    {
        //print chosen chairman
        cout << _chairman->getName() << " is the chairman of " << _name << endl;
        //update all party members of the chosen chairman
        notify();
    }
    return true;
}

/*
 * sum all the power of the party for elections
 */
int Party::partyPower() {
    //initialize sum
    int partyPower = 0;
    //go over members of party
    vector<Politician*>::iterator it;
    for (it = _members.begin();it != _members.end(); ++it)
        //add their power to the sum
        partyPower += (*it)->getElectionsPower();
    //print party power
    cout << "Party: "<<getName()<<",Power: "<<partyPower<<endl;
    //return party power
    return partyPower;
}
/*
 * this class is a subject therefore has to update its observers
 * in this case, the observers are the party members
 * returns bool, true if successful and false if not
 */
bool Party::notify() {
    //go over party members
    vector<Politician*>::iterator it;
    for (it = _members.begin();it != _members.end(); ++it)
    {
        //update each party member
        if(!((*it)->update()))
            //if failed
            return false;
    }
    return true;
}
