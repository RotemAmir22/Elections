//
// Created by ise on 1/8/23.
//

#include <fstream>
#include <algorithm>
#include "PoliticalSys.h"
#include "RepublicanLeader.h"
#include "RepublicanSocial.h"
#include "DemocraticLeader.h"
#include "DemocraticSocial.h"
#include "RepublicanParty.h"
#include "DemocraticParty.h"
#include "Exceptions.h"

/*
 * FUNCTOR
 * class is used to compare parties by size
 * has a public operator()
 */
class Compare{
public:
    bool operator()(Party *party1, Party *party2)
    {
        return party1->getSize()<party2->getSize();
    }
};

/*
 * destructor
 * clears all vector from system
 */
PoliticalSys::~PoliticalSys() {
    for(int i=0; i<(int)_politicians.size();i++)
    {
        //deletes all politicians from system
        delete _politicians[i];
    }
    for(int j=0; j<(int)_parties.size();j++)
    {
        //deletes all parties from system
        delete _parties[j];
    }
    _politicians.clear();
    _parties.clear();
    _heapOfParties.clear();

}

/*
 * helper function
 * check if party is suitable for politician
 * return bool, true is successful, false if not
 */
bool PoliticalSys::checkMatch(Politician* politician, Party* party)
{
    //check pointer
    if(politician == nullptr || party == nullptr)
        return false;

    //if politician is not a member of a party
    if(politician->getParty() == nullptr)
    {
        //add politician to party
        if(!(politician->canBeMember(party)))
            return false;
    }
        //if politicians party is larger than the party
    else if(politician->getParty()->getSize()> party->getSize())
    {
        //temp holder of old party
        Party *tempPointer = politician->getParty();
        //add politician to new party
        if((politician->canBeMember(party)))
            //remove politician from old part
            if(!(tempPointer->removeMember(politician)))
                return false;
    }
    return true;
}

/*
 * constructor
 * gets a file and extracts info into vectors
 */
PoliticalSys::PoliticalSys(const char* filePath){
    //open file stream
    fstream file;
    file.open(filePath,ios::in);
    //use to read line
    string line;
    //while there still is text in file
    while(!file.eof())
    {
        //parties
        if(line == "Parties:\r")
        {
            //get next line
            getline(file,line);
            //go over parties until end of file
            while(!file.eof())
            {
                //get information from line
                string name = line.substr(0,line.find(' '));
                line.erase(0,line.find(' ')+1);
                string party;
                if(line.find('\r'))
                    party = line.substr(0,line.find('\r'));
                else
                    party = line.substr(0,line.find(' '));
                //create new party
                Party *newParty = nullptr;
                //if democratic party
                if(party == "D") {
                    //create new democratic party
                    newParty = new DemocraticParty(name);

                }
                //if republican party
                else if(party == "R")
                {
                    //create new republican party
                    newParty = new RepublicanParty(name);
                    //_republicanParties.push_back(newParty);
                }
                    //go over politicians to add members to party
                    vector<Politician*>::iterator it;
                    for (it = _politicians.begin();it != _politicians.end(); ++it)
                    {
                        //use helper function
                        checkMatch(*it,newParty);
                    }

                //add party to maximum heap and vector
                _parties.push_back(newParty);
                _heapOfParties.push_back(newParty);
                //continue reading file
                getline(file,line);
            }
        }
        //get next line
        getline(file,line);
        //politicians
        if(line =="Politicians:\r")
        {
            //get next line
            getline(file,line);
            //go until end of politicians
            while (line!="Parties:\r")
            {
                //extract info from line
                string first = line.substr(0,line.find(' '));
                line.erase(0,line.find(' ')+1);
                string last = line.substr(0,line.find(' '));
                line.erase(0,line.find(' ')+1);
                string id = line.substr(0,line.find(' '));
                line.erase(0,line.find(' ')+1);
                int power = stoi(line.substr(0, line.find(' ')));
                line.erase(0,line.find(' ')+1);
                string partyType = line.substr(0,line.find(' '));
                line.erase(0,line.find(' ')+1);
                string type = line.substr(0,line.find('\r'));

                //new politician
                Politician *newPolitician = nullptr;
                //if republican
                if(partyType == "R")
                {
                    //if a leader
                    if (type == "L")
                        newPolitician = new RepublicanLeader(first,last,id,power);
                        //if social
                    else if (type == "S")
                        newPolitician = new RepublicanSocial(first,last,id,power);

                }

                    //if democrat
                else if (partyType == "D")
                {
                    //if a leader
                    if(type == "L")
                        newPolitician = new DemocraticLeader(first,last,id,power);
                        //if social
                    else if (type == "S")
                        newPolitician = new DemocraticSocial(first,last,id,power);

                }

                //add to vector
                _politicians.push_back(newPolitician);
                getline(file,line);
            }
        }
    }
    //last party
    if(line != "")
    {
        string name = line.substr(0,line.find(' '));
        line.erase(0,line.find(' ')+1);
        string party;
        if(line.find('\r'))
            party = line.substr(0,line.find('\r'));
        else
            party = line.substr(0,line.find(' '));
        //create new party
        Party *newParty = nullptr;
        //if democratic party
        if(party == "D") {
            //create new democratic party
            newParty = new DemocraticParty(name);

        }
        else if(party == "R") {
            //create new republican party
            newParty = new RepublicanParty(name);
        }
        //go over politicians to add members to party
        vector<Politician*>::iterator it;
        for (it = _politicians.begin();it != _politicians.end(); ++it)
        {
            //use helper function
            checkMatch(*it,newParty);
        }

        //add party to maximum heap and vector
        _parties.push_back(newParty);
        _heapOfParties.push_back(newParty);
    }


    //update heap
    make_heap(_heapOfParties.begin(),_heapOfParties.end(),Compare());
    //close file
    file.close();
}

/*
 * adds politician to system
 */
bool PoliticalSys::addPolitician(){

    string first;
    string last;
    string id;
    string s_power;
    string partyType;
    string type;
    cout << "---Create Politician---"<< endl;

    //if input is incorrect, try again from here
    tryAgain:

    //gets details from user
    cout <<"First name:"<<endl;
    cin >> first;
    cout <<"Last name:"<<endl;
    cin >> last;
    cout <<"ID:"<<endl;
    cin >> id;
    cout <<"Power:"<<endl;
    cin >> s_power;
    cout <<"Republican or Democratic person"<< endl;
    cin >> partyType;
    cout <<"Leader or Social"<< endl;
    cin >> type;

    //new politician
    Politician *newPolitician = nullptr;

    //check input
    try{
		//if id in system
		vector<Politician*>::iterator poly;
		for (poly = _politicians.begin(); poly != _politicians.end(); ++poly)
		{
			if((*poly)->getID() == id)
			{
                throw InvalidInput();
			}
		}
		//if id or power not a number
		if(id.find_first_not_of("0123456789") != string::npos || s_power.find_first_not_of("0123456789") != string::npos)
		{
            throw InvalidInput();
		}
		//if id not a positive number
		if(stoi(id)<=0)
		{
            throw InvalidInput();
		}
		//if power not a positive number
		if(stoi(s_power)<=0)
		{
            throw InvalidInput();
		}

		//check types
		if(type != "S" )
		{
			if(type != "L")
			{
                throw InvalidInput();
			}
		}

		if(partyType != "R" )
		{
			if(partyType != "D")
			{
                throw InvalidInput();
			}
		}
    }
    catch(InvalidInput& e)
    {
    	cout <<e.what()<<endl;
        goto tryAgain;
    }

    //convert power from string to int
    int power = stoi(s_power);

    //if republican
    if(partyType == "R")
    {
        //if leader
        if (type == "L")
            newPolitician = new RepublicanLeader(first,last,id,power);
            //if social
        else if (type == "S")
            newPolitician = new RepublicanSocial(first,last,id,power);
    }
        //if democrat
    else if (partyType == "D")
    {
        //if leader
        if(type == "L")
            newPolitician = new DemocraticLeader(first,last,id,power);
            //if social
        else if (type == "S")
            newPolitician = new DemocraticSocial(first,last,id,power);
        vector<Party*>::iterator it;
        for (it = _parties.begin();it != _parties.end(); ++it)
        {
            checkMatch(newPolitician,*it);
        }

    }
    //add to vector
    _politicians.push_back(newPolitician);
    //update heap
    make_heap(_heapOfParties.begin(),_heapOfParties.end(),Compare());
    return true;
}

/*
 * add party to system
 */
bool PoliticalSys::addParty(){
    string name;
    string partyType;
    cout << "---Create Party---"<< endl;
    //if input is incorrect, try again from here
    tryAgain:
    //get details from user
    cout <<"Name:"<<endl;
    cin >> name;
    cout <<"Republican or Democratic party"<<endl;
    cin >> partyType;
    //new partyType
    Party *newParty = nullptr;
    //check input
    try{
		//check if name in system
		vector<Party*>::iterator it_party;
		for (it_party = _parties.begin(); it_party != _parties.end(); ++it_party)
		{
			if((*it_party)->getName() == name)
			{
                throw InvalidInput();
			}
		}
		//check type
		if(partyType != "R" )
		{
			if(partyType != "D")
			{
				throw InvalidInput();
			}
		}
    }
    catch(InvalidInput& e)
    {
    	cout<<e.what()<<endl;
        goto tryAgain;
    }

    //if democratic
    if(partyType == "D")
    {
        //new partyType
        newParty = new DemocraticParty(name);
    }
        //if republican
    else if(partyType == "R")
    {
        //new partyType
        newParty = new RepublicanParty(name);
    }
    vector<Politician*>::iterator it;
    for (it = _politicians.begin();it != _politicians.end(); ++it)
    {
        checkMatch((*it),newParty);
    }

    //add to vectors and update heap
    _parties.push_back(newParty);
    _heapOfParties.push_back(newParty);
    make_heap(_heapOfParties.begin(),_heapOfParties.end(),Compare());
    return true;
}

/*
 * remove politician from system
 */
bool PoliticalSys::removePolitician() {
    //get details from user
    string id;
    cout << "---Remove Politician---"<< endl;
    //if input is incorrect, try again from here
    tryAgain:
    cout <<"Enter the ID:"<<endl;
    cin >> id;

    //check input
    vector<Politician*>::iterator it;
    try{
        int i=0;
        //if id not in system
        for (it = _politicians.begin();it != _politicians.end(); ++it)
        {
            if((*it)->getID()!=id)
                i++;
        }
        //gone over all and not found
        if(i==(int)_politicians.size())
        {
            throw InvalidID();
        }
        //if id given not a number
        if(id.find_first_not_of("0123456789") != string::npos)
        {
            throw InvalidID();
        }
        //if id given not a positive number
        if(stoi(id)<=0)
        {
            throw InvalidID();
        }
    }
    catch(InvalidID& e)
    {
        cout<<e.what()<<endl;
        goto tryAgain;
    }

    //catch pointer before erasing from vector
    Politician *tempPointerPolitician = nullptr;
    //go over politicians and look for politician
    for (it = _politicians.begin();it != _politicians.end(); ++it)
    {
        if(id == (*it)->getID())//if found
        {
            //remove form vector and party
            (*it)->getParty()->removeMember((*it));
            tempPointerPolitician = *it;
            _politicians.erase(it);
            break;
        }
    }
    //update heap
    make_heap(_heapOfParties.begin(),_heapOfParties.end(),Compare());
    delete tempPointerPolitician;
    return true;
}

/*
 * remove party from system
 */
bool PoliticalSys::removeParty() {
    //get details from user
    string name;
    cout << "---Remove Party---"<< endl;
    //if input is incorrect, try again from here
    tryAgain:
    cout <<"Enter party name:"<<endl;
    cin >> name;

    int k =0;
    //catch pointer before erasing from vector
    Party *tempPointerParty;
    vector<Party*>::iterator it_party;
    //check if party name is valid
    try{
        for (it_party = _parties.begin(); it_party != _parties.end(); ++it_party)
        {
            if((*it_party)->getName()!=name)
                k++;
        }
        //if not found in parties vector
        if(k==(int)_parties.size())
        {
            throw InvalidName();
        }
    }
    catch(InvalidName& e)
    {
        cout <<e.what()<<endl;
        goto tryAgain;
    }

    //go over parties
    for (it_party = _parties.begin(); it_party != _parties.end(); ++it_party)
    {
        if(name == (*it_party)->getName())//if found
        {
            tempPointerParty=*it_party;
            _parties.erase(it_party);
            //update members of party -> they need to find another party to join
            //go over form first to last
            int size = tempPointerParty->getSize();
            for(int i =0; i< size ;i++)
            {
                //remove first each time
                Politician *removed = tempPointerParty->getMembers()[0];
                tempPointerParty->removeMember(removed);
                //update party to null -> party removed
                removed->setParty(nullptr);
                //go over other parties and join one
                vector<Party*>::iterator it;
                for (it = _parties.begin(); it != _parties.end(); ++it)
                {
                    //check match and add politician
                    checkMatch(removed, (*it));
                }
            }
            break;
        }
    }
    //update heap
    vector<Party*>::iterator removeParty;
    for(removeParty = _heapOfParties.begin(); removeParty != _heapOfParties.end(); ++removeParty)
    {
        if((*removeParty)->getName() == name)
        {
            //remove from vector
            _heapOfParties.erase(removeParty);
            break;
        }
    }
    make_heap(_heapOfParties.begin(),_heapOfParties.end(),Compare());
    //delete party object
    delete tempPointerParty;
    return true;
}

/*
 * elections happen in 3 stages
 * 1. primaries
 * 2. elections
 * 3. results
 */
bool PoliticalSys::elections() {
    //check if there are any parties or politicians
    if(_politicians.empty() || _parties.empty())
        return false;

    //use to calculate winner
    int maxPower=0;
    int partyPower=0;
    Party *winner= nullptr;

    //stage 1
    cout<<"----Primaries----"<<endl;
    //go over parties and activate the primaries
    vector<Party*>::iterator it_primaries;
    for (it_primaries = _parties.begin(); it_primaries != _parties.end(); ++it_primaries)
    {
        (*it_primaries)->primaries();
    }

    //stage 2
    cout<<"----Elections----"<<endl;
    //go over parties and find the party with maximum power
    vector<Party*>::iterator it_partyPower;
    for (it_partyPower = _parties.begin(); it_partyPower != _parties.end(); ++it_partyPower)
    {
        partyPower = (*it_partyPower)->partyPower() ;
        if(partyPower > maxPower)
        {
            maxPower=partyPower;
            winner=*it_partyPower;
        }
    }

    //stage 3
    cout<<"----Elections Results----"<<endl;
    //print winner of election
    if(winner->getChairman()== nullptr || winner== nullptr)
        cout << winner->getName()<<" party won the elections and None is the prime minister"<<endl;
    else
        cout << winner->getName()<<" party won the elections and " <<winner->getChairman()->getName()<< " is the prime minister"<<endl;
    return true;
}

/*
 * print politicians in system
 */
bool PoliticalSys::printPoliticians() {
    cout<<"----Politicians----"<<endl;
    //go over politicians and print
    vector<Politician*>::iterator it;
    for (it = _politicians.begin(); it != _politicians.end(); ++it)
    {
        if(*it == nullptr)
            break;
        (*it)->displayPolitician();
    }
    return true;
}

/*
 * print parties in system
 */
bool PoliticalSys::printParties() {
    cout<<"----Parties----"<<endl;
    //go over parties and print
    vector<Party*>::iterator it;
    for (it = _parties.begin(); it != _parties.end(); ++it)
        (*it)->displayParty();
    return true;
}

/*
 * use heap and return the largest party
 */
bool PoliticalSys::BiggestParty() {
    cout<<"----Biggest Party----"<<endl;
    cout <<"["<<_heapOfParties.front()->getName()<<","<<_heapOfParties.front()->getSize()<<"]"<<endl;
    return true;
}


