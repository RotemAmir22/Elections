//
// Created by ise on 1/7/23.
//

#include "DemocraticSocial.h"

/*
 * function prints the politician in format
 * return true - print successful
 */
bool DemocraticSocial::displayPolitician()const {
    if(_chairman!= nullptr)//check if there is a chairman, if not then print none as chairmans name
        cout << "Democratic Person:"<<_firstName << " " << _lastName << ", Id:"<< _ID<< ", Power:"<< _power<<", Type:S, Chairman: "<<_chairman->getName()<<endl;
    else
        cout << "Democratic Person:"<<_firstName << " " << _lastName << ", Id:"<< _ID<< ", Power:"<< _power<<", Type:S, Chairman: None"<<endl;
    return true;
}
