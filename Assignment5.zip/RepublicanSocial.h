//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_REPUBLICANSOCIAL_H
#define ASSIGNMENT5_REPUBLICANSOCIAL_H
#include "Politician.h"
/*
 * this class is to help identify the politician
 * all the republican social are of this class
 * publicly inherits from politician
 * has no additional members
 */
class RepublicanSocial : public Politician{
public:
    //constructor
    RepublicanSocial(string firstName, string lastName, string ID, int power) :Politician(firstName,lastName,ID,power){}
    //destructor
    virtual ~RepublicanSocial(){}
    //print politician
    virtual bool displayPolitician()const;
    //gets politicians power at primaries
    //in primaries, social politician cant be elected to chairman
    virtual int getPrimariesPower()const{return -1;}
    //gets politicians power at elections
    // social politician doubles its power in elections
    virtual int getElectionsPower()const{return _power*2;}
    //check if politician can be a member of a party
    virtual bool canBeMember(Party *party){return party->handleRepublican(this);};

};


#endif //ASSIGNMENT5_REPUBLICANSOCIAL_H
