//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_REPUBLICANPARTY_H
#define ASSIGNMENT5_REPUBLICANPARTY_H
#include "Party.h"
/*
 * this class is to help identify the parties
 * all the republic parties are of this class
 * publicly inherits from party
 * has no additional members
 */
class RepublicanParty: public Party {
public:
    //constructor
    RepublicanParty(string name): Party(name){}
    //destructor
    virtual ~RepublicanParty(){}
    //print
    virtual bool displayParty();
    //if politician can be part of party, adds, if not, false
    virtual bool handleRepublican(Politician *politician){return addMember(politician);}
    virtual bool handleDemocrat(Politician *politician){return false;}
};


#endif //ASSIGNMENT5_REPUBLICANPARTY_H
