//
// Created by ise on 1/8/23.
//

#ifndef ASSIGNMENT5_POLITICALSYS_H
#define ASSIGNMENT5_POLITICALSYS_H
#include <vector>
#include "Politician.h"
#include "Party.h"
/*
 * this class run the political system
 * has private members that are used to identify the different kinds of politicians and parties
 * all new elements are added to the end of te vector
 *  - politicians -> all the politicians in system
 *  - parties -> all parties in system
 *  - democrats -> all democrat politicians in system
 *  - republicans -> all republican politicians in system
 *  - democratParties -> all democrat parties in system
 *  - republicanParties -> all republican parties in system
 *  - heapOfParties -> maximum heap defined by size of party
 */
class PoliticalSys {
private:
    vector<Politician*> _politicians;
    vector<Party*> _parties;
    vector<Party*> _heapOfParties;
public:
    //constructors
    //default
    PoliticalSys(){}
    //constructor with file path
    PoliticalSys(const char* filePath)noexcept(false);//throw(std::bad_alloc)
    //destructor
    ~PoliticalSys();
    //methods from main
    bool addPolitician()noexcept(false);//throw(std::bad_alloc)
    bool addParty()noexcept(false);//throw(std::bad_alloc)
    bool removePolitician();
    bool removeParty();
    bool elections();
    bool printPoliticians();
    bool printParties();
    bool BiggestParty();
    //helper method
    static bool checkMatch(Politician *politician,  Party *party);
};


#endif //ASSIGNMENT5_POLITICALSYS_H
