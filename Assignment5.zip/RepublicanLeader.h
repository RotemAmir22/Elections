//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_REPUBLICANLEADER_H
#define ASSIGNMENT5_REPUBLICANLEADER_H
#include "Politician.h"
/*
 * this class is to help identify the politician
 * all the republican leaders are of this class
 * publicly inherits from politician
 * has no additional members
 */
class RepublicanLeader : public Politician{
public:
    //constructor
    RepublicanLeader(string firstName, string lastName, string ID, int power) :Politician(firstName,lastName,ID,power){}
    //destructor
    virtual ~RepublicanLeader(){}
    //print politician
    virtual bool displayPolitician()const;
    //gets politicians power at primaries
    virtual int getPrimariesPower()const{return _power;}
    //gets politicians power at elections
    virtual int getElectionsPower()const{return _power;}
    //check if politician can be a member of a party
    virtual bool canBeMember(Party *party){return party->handleRepublican(this);};
};


#endif //ASSIGNMENT5_REPUBLICANLEADER_H
