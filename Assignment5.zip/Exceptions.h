//
// Created by ise on 1/14/23.
//

#ifndef ASSIGNMENT5_EXCEPTIONS_H
#define ASSIGNMENT5_EXCEPTIONS_H
#include <exception>
/*
 * this header file is for all the different custom exceptions that can be thrown
 */

//invalid detail when creating a politician or party
class InvalidInput : public std::exception
{
public:
    const char * what() const noexcept override{return "Please enter valid details";}//message
};

//invalid id when trying to remove a politician
class InvalidID : public std::exception
{
public:
    const char * what() const noexcept override{return "Please enter valid id";}//message
};

//invalid name when trying to remove a party
class InvalidName : public std::exception
{
public:
    const char * what() const noexcept override{return "Please enter valid name";}//message
};
#endif //ASSIGNMENT5_EXCEPTIONS_H
