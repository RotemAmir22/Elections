//
// Created by ise on 1/7/23.
//

#ifndef ASSIGNMENT5_DEMOCRATICPARTY_H
#define ASSIGNMENT5_DEMOCRATICPARTY_H
#include "Party.h"
/*
 * this class is to help identify the parties
 * all the democratic parties are of this class
 * publicly inherits from party
 * has no additional members
 */
class DemocraticParty : public Party{
public:
    //constructor
    DemocraticParty(string name): Party(name){}
    //destructor
    virtual ~DemocraticParty(){}
    //print
    virtual bool displayParty();
    //if politician can be part of party, adds, if not, false
    virtual bool handleRepublican(Politician *politician){return false;}
    virtual bool handleDemocrat(Politician *politician){return addMember(politician);}
};


#endif //ASSIGNMENT5_DEMOCRATICPARTY_H
