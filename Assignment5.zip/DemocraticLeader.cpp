//
// Created by ise on 1/7/23.
//

#include "DemocraticLeader.h"
/*
 * function prints the politician in format
 * return true - print successful
 */
bool DemocraticLeader::displayPolitician()const {
    if(_chairman!= nullptr)//check if there is a chairman, if not then print none as chairmans name
        cout << "Democratic Person:"<<_firstName << " " << _lastName << ", Id:"<< _ID<< ", Power:"<< _power<<", Type:L, Chairman: "<<_chairman->getName()<<endl;
    else
        cout << "Democratic Person:"<<_firstName << " " << _lastName << ", Id:"<< _ID<< ", Power:"<< _power<<", Type:L, Chairman: None"<<endl;
    return true;
}
