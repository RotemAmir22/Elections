//
// Created by ise on 1/7/23.
//

#include "RepublicanParty.h"
/*
 * function prints the party in format
 * return true - print successful
 */
bool RepublicanParty::displayParty() {
    if(_chairman!= nullptr)//check if there is a chairman, if not then print none as chairmans name
        cout << "Republican Party: "<< _name <<", chairman:"<<_chairman->getName()<<", Size:"<<_size<<endl;
    else
        cout << "Republican Party: "<< _name <<", chairman:None, Size:"<<_size<<endl;
    //go over politicians in party and print them in format
    vector<Politician*>::iterator it;
    for (it = _members.begin();it != _members.end(); ++it)
    {
        cout << "\t";
        bool printPolitician =(*it)->displayPolitician();
        //check if print of politician was successful
        if (!printPolitician)
            return false;
    }
    return true;
}
